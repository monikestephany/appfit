package br.edu.sumare.appfit.Domain.Aula;

import java.util.HashMap;

public class AulaAux extends HashMap<String, String> {
    public static final String ID = "id";
    public static final String PROFESSOR = "professor";
    public static final String HORA = "hora";
}
