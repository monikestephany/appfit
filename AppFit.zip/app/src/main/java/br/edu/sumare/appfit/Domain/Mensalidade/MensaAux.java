package br.edu.sumare.appfit.Domain.Mensalidade;

import java.util.HashMap;

public class MensaAux extends HashMap<String, String> {
    public static final String ID = "ID";
    public static final String STATUS = "STATUS";
    public static final String VALOR = "VALOR";
    public static final String VENCIMENTO = "VENCIMENTO";
    public static final String BOLETO = "BOLETO";
}
